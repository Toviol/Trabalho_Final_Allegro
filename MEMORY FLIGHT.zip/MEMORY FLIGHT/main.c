#include <stdio.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>
#define WIDTH 1200
#define HEIGTH 700
#define FPS 60

int main(void)
{
  bool sair = false;
  bool redraw = true;
  ALLEGRO_DISPLAY *display = NULL;
  ALLEGRO_EVENT_QUEUE *event_queue = NULL;
  ALLEGRO_AUDIO_STREAM *musica = NULL;
  ALLEGRO_AUDIO_STREAM *musica2 = NULL;
  ALLEGRO_AUDIO_STREAM *musica3 = NULL;
  ALLEGRO_SAMPLE *sample = NULL;
  ALLEGRO_BITMAP *img_comeco = NULL;
  ALLEGRO_BITMAP *img_start = NULL;
  ALLEGRO_BITMAP *img_sair = NULL;
  ALLEGRO_BITMAP *img_briefing = NULL;
  ALLEGRO_BITMAP *img_1grdgreen = NULL;
  ALLEGRO_BITMAP *img_1fasevermelhos = NULL;
  ALLEGRO_BITMAP *img_1doisgreen = NULL;
  ALLEGRO_BITMAP *img_briefing2 = NULL;
  ALLEGRO_BITMAP *img_2grdgreen = NULL;
  ALLEGRO_BITMAP *img_2fasevermelhos = NULL;
  ALLEGRO_BITMAP *img_2doisgreen = NULL;
  ALLEGRO_BITMAP *img_2tresgreen = NULL;
  ALLEGRO_BITMAP *img_win = NULL;



  ALLEGRO_TIMER *timer = NULL;
  al_init();
  al_init_image_addon();
  al_install_keyboard();
  al_install_mouse();
  al_install_audio();
  al_init_acodec_addon();
  al_reserve_samples(1);



  display = al_create_display(WIDTH, HEIGTH);
  event_queue = al_create_event_queue();
  timer = al_create_timer(1.0/ FPS);

  img_comeco = al_load_bitmap("imagens/comeco.png");
  img_start = al_load_bitmap("imagens/start.png");
  img_sair = al_load_bitmap("imagens/sair.png");
  img_briefing = al_load_bitmap("imagens/briefing.png");
  img_1fasevermelhos = al_load_bitmap("imagens/1fasevermelhos.png");
  img_1grdgreen = al_load_bitmap("imagens/1grdgreen.png");
  img_1doisgreen = al_load_bitmap("imagens/1doisgreen.png");
  img_briefing2 = al_load_bitmap("imagens/briefieng2fase.png");
  img_2fasevermelhos = al_load_bitmap("imagens/2fasevermelhos.png");
  img_2grdgreen = al_load_bitmap("imagens/2grdgreen.png");
  img_2doisgreen = al_load_bitmap("imagens/2doisgreen.png");
  img_2tresgreen = al_load_bitmap("imagens/2tresgreen.png");
  img_win = al_load_bitmap("imagens/win.png");
  musica = al_load_audio_stream("sfx/musica1.ogg", 4, 1024);
  musica2 = al_load_audio_stream("sfx/musica2.ogg", 4, 1024);
  musica3 = al_load_audio_stream("sfx/musica3.ogg", 4, 1024);
  sample = al_load_sample("sfx/Switch.ogg");


  al_register_event_source(event_queue, al_get_display_event_source(display));
  al_register_event_source(event_queue, al_get_mouse_event_source());
  al_register_event_source(event_queue, al_get_keyboard_event_source());
  al_register_event_source(event_queue, al_get_timer_event_source(timer));

  al_draw_bitmap(img_comeco, 0, 0, 0);
  al_flip_display();
  al_start_timer(timer);
    while(!sair){

        ALLEGRO_EVENT event;
        al_wait_for_event(event_queue, &event);
        al_attach_audio_stream_to_mixer(musica, al_get_default_mixer());
        al_set_audio_stream_playing(musica, true);

        if(event.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
            sair = true;

        if(event.type == ALLEGRO_EVENT_TIMER)
            redraw = true;

        if(event.type == ALLEGRO_EVENT_MOUSE_AXES)
        {
                    if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP)
            {
                al_attach_audio_stream_to_mixer(sample, al_get_default_mixer());
                al_play_sample(sample, 1.0, 0.0, 0.0, ALLEGRO_PLAYMODE_ONCE, NULL);
            }
        }

        if(event.type == ALLEGRO_EVENT_MOUSE_AXES){

            if((event.mouse.x > 752 && event.mouse.x < 1031 && event.mouse.y > 458 && event.mouse.y < 539) && redraw){//start
                redraw = false;
                al_draw_bitmap(img_start, 0, 0, 0);
                al_flip_display();
            }else if(event.mouse.x > 752 && event.mouse.x < 1031 && event.mouse.y > 560 && event.mouse.y < 637 && redraw){//exit
                redraw = false;
                al_draw_bitmap(img_sair, 0, 0, 0);
                al_flip_display();
            }else if(redraw){//DEFAULT
                redraw = false;
                al_draw_bitmap(img_comeco, 0, 0, 0);
                al_flip_display();
            }
        }

        if(event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN){

            if(event.mouse.x > 752 && event.mouse.x < 1031 && event.mouse.y > 560 && event.mouse.y < 637){//clicou exit

                     al_destroy_display(display);
                     al_destroy_event_queue(event_queue);

            }
        }
        if(event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN){

            if(event.mouse.x > 752 && event.mouse.x < 1031 && event.mouse.y > 458 && event.mouse.y < 539){//clicou start

                bool sairserver = false;
                redraw = true;
                al_set_audio_stream_playing(musica, false);
                al_attach_audio_stream_to_mixer(musica2, al_get_default_mixer());
                al_set_audio_stream_playing(musica2, true);
                al_draw_bitmap(img_briefing, 0, 0, 0);
                al_flip_display();
                al_rest(10);
                al_set_audio_stream_playing(musica2, false);
                al_attach_audio_stream_to_mixer(musica3, al_get_default_mixer());
                al_set_audio_stream_playing(musica3, true);
                al_draw_bitmap(img_2fasevermelhos, 0, 0, 0);
                al_flip_display();

        while(!sair){

        ALLEGRO_EVENT event;
        al_wait_for_event(event_queue, &event);

        if(event.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
            sair = true;

        if(event.type == ALLEGRO_EVENT_TIMER)
            redraw = true;

        if(event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP){

            if((event.mouse.x > 422 && event.mouse.x < 456 && event.mouse.y > 297 && event.mouse.y < 330) && redraw){//botao esquerdo verde segunda fase
                redraw = false;
                al_draw_bitmap(img_2grdgreen, 0, 0, 0);
                al_flip_display();
            }else if(event.mouse.x > 746 && event.mouse.x < 780 && event.mouse.y > 297 && event.mouse.y < 330 && redraw){//dois verdes
                redraw = false;
                al_draw_bitmap(img_2doisgreen, 0, 0, 0);
                al_flip_display();
            }else if(event.mouse.x > 583 && event.mouse.x < 653 && event.mouse.y > 297 && event.mouse.y < 330 && redraw){//tres verdes
                redraw = false;
                al_draw_bitmap(img_2tresgreen, 0, 0, 0);
                al_flip_display();
      }
    }
                    }

                while(!sairserver){
                    ALLEGRO_EVENT event2;
                    al_wait_for_event(event_queue, &event2);

                    if(event2.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
                        sairserver = true;
                        sair = true;

                    if(event2.type == ALLEGRO_EVENT_TIMER)
                        redraw = true;

            }
        }
    }
    }

  return 0;
}
